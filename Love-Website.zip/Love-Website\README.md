# Love Website for Jana ❤️

This is a personalized, Janmashtami-themed website created for Gokul and Jana's 8-month anniversary.

## How to use:
1. Place your two photos inside the `assets/images/` folder.
   - Name the first one: `jg.jpeg` (This will show on the Welcome page).
   - Name the second one: `gj.jpeg` (This will show on the Memories page).
2. Open `index.html` in your web browser.
3. Enjoy the magic! ✨
