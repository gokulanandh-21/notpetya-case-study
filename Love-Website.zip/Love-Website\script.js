// LOVE Object for Confetti (Replacing the external library requirement from snippet)
const LOVE = {
    confettiBurst: function() {
        if(window.confetti){
            confetti({
                particleCount: 100,
                spread: 70,
                origin: { y: 0.6 },
                colors: ['#ff2d55', '#ffffff', '#ff99a8']
            });
        }
    }
};

// Magical Entrance Animation
window.onload = () => {
    if(window.gsap) {
        gsap.to("#intro-line-1", { opacity: 1, y: 0, duration: 2, ease: "power2.out" });
        gsap.to("#intro-line-2", { opacity: 1, y: 0, duration: 2, delay: 2, ease: "power2.out" });
        gsap.to("#intro-line-3", { opacity: 1, y: 0, duration: 2, delay: 4, ease: "power2.out" });
        gsap.to("#unlock-btn", { opacity: 1, duration: 1, delay: 6 });
    }
};

function unlockWorld() {
    LOVE.confettiBurst();
    nextScreen('entrance-screen', 'welcome-screen');
}

// Screen Transitions
function nextScreen(currentId, nextId) {
    const current = document.getElementById(currentId);
    const next = document.getElementById(nextId);
    
    current.classList.remove('active');
    setTimeout(() => {
        current.classList.add('hidden');
        next.classList.remove('hidden');
        
        setTimeout(() => {
            next.classList.add('active');
            
            // Start typewriter if it's the letter screen
            if (nextId === 'letter-screen') {
                setTimeout(() => {
                    startTypewriter();
                }, 500);
            }
        }, 50);
    }, 800);
}

// Letter Typewriter Logic
const letterText = "My Permanent, \n\nHappy 8 Months, and Happy Janmashtami. From the moment you walked into my life, you turned my chaos into peace. I know I have said it a million times, but even a million is not enough to express how breathtakingly beautiful you are to me. \n\nYou are my lover, my best friend, my second mom, and my ultimate destination. I look at you and I see the rest of my life right in front of my eyes. \n\nI promise to hold your hand through every storm. I promise to wipe your tears before they fall. We are not just a passing phase, we are an eternal reality. I will love you fiercely and endlessly, until my very last breath.\n\nForever Yours,\nGokul ❤️";

let isTyping = false;
function startTypewriter() {
    if (isTyping) return;
    isTyping = true;
    
    document.getElementById('letter-inst').classList.add('hidden');
    typeWriterEffect(letterText, 0);
}

function typeWriterEffect(text, index) {
    const container = document.getElementById('typewriter-text');
    
    if (index === 0) {
        container.innerHTML = '<span id="tw-content"></span><span class="typewriter-cursor"></span>';
    }
    
    if (index < text.length) {
        const char = text.charAt(index);
        const span = document.getElementById('tw-content');
        
        if (char === '\n') {
            span.innerHTML += '<br>';
        } else {
            span.innerHTML += char;
        }
        
        let speed = Math.random() * 30 + 30; // Slightly slower for handwriting feel
        if (char === '.' || char === ',') speed += 300; 
        
        // Auto scroll to bottom of letter paper if it gets too long
        const paper = document.getElementById('main-letter');
        paper.scrollTop = paper.scrollHeight;
        
        setTimeout(() => {
            typeWriterEffect(text, index + 1);
        }, speed);
    } else {
        document.querySelector('.typewriter-cursor').style.display = 'none';
        document.getElementById('btn-final').classList.remove('hidden');
    }
}

// Cursor Heart Trail
let lastHeartTime = 0;
document.addEventListener('mousemove', function(e) {
    const now = Date.now();
    if (now - lastHeartTime < 50) return; 
    lastHeartTime = now;

    const heart = document.createElement('i');
    heart.className = 'fa-solid fa-heart cursor-heart';
    
    heart.style.left = (e.pageX - 10) + 'px';
    heart.style.top = (e.pageY - 10) + 'px';
    
    const size = Math.random() * 0.5 + 0.5;
    heart.style.transform = `scale(${size})`;
    heart.style.transition = 'all 1s ease-out';
    
    document.body.appendChild(heart);
    
    requestAnimationFrame(() => {
        heart.style.transform = `scale(${size}) translateY(-30px)`;
        heart.style.opacity = '0';
    });
    
    setTimeout(() => {
        heart.remove();
    }, 1000);
});
